import { useState, useEffect, useRef } from 'react';
import { platforms } from '@/data/platforms';
import { calculatePlans } from '@/lib/optimizer';
import { useColorScheme } from '@/hooks/useColorScheme';
import { useSavedInputs } from '@/hooks/useSavedInputs';
import PlatformSelector from '@/components/PlatformSelector';
import AlgorithmWindowControl from '@/components/AlgorithmWindowControl';
import MultiPostControls from '@/components/MultiPostControls';
import LocationInputs from '@/components/LocationInputs';
import AgeGroupInputs from '@/components/AgeGroupInputs';
import GenderInputs from '@/components/GenderInputs';
import ColorSchemeSettings from '@/components/ColorSchemeSettings';
import FunctionModeSelector from '@/components/FunctionModeSelector';
import AcquisitionGroups, { makeBlankGroup } from '@/components/AcquisitionGroups';
import ResultsPanel from '@/components/ResultsPanel';
import ErrorMessage from '@/components/ErrorMessage';
import { usePlatformData } from '@/hooks/usePlatformData';
import AmbientBackground from '@/components/effects/AmbientBackground';
import TiltCard from '@/components/effects/TiltCard';
import Reveal from '@/components/effects/Reveal';
import { ArrowRight, History, ChevronDown, ChevronUp } from 'lucide-react';

export default function Home() {
  const { schemeId, setSchemeId, themeMode, toggleTheme } = useColorScheme();
  const { savedInputs, saveInput } = useSavedInputs();

  const [platform, setPlatform] = useState('instagram');
  const [mode, setMode] = useState('maximization');
  const [acquisitionGroups, setAcquisitionGroups] = useState([makeBlankGroup(0)]);
  const [algorithmWindow, setAlgorithmWindow] = useState(2);
  const [numPosts, setNumPosts] = useState(1);
  const [gaps, setGaps] = useState([2]);
  const [locations, setLocations] = useState(
    Array(5).fill(null).map(() => ({ country: '', offset: null, percentage: '' }))
  );
  const [ageGroups, setAgeGroups] = useState([]);
  const [gender, setGender] = useState({ men: '', women: '' });
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [calculating, setCalculating] = useState(false);
  const { data: platformData, refreshing, refresh } = usePlatformData(platform);
  const resultsRef = useRef(null);

  // Reset age groups when platform changes
  useEffect(() => {
    const p = platforms[platform];
    setAgeGroups(p.ageGroups.map(ag => ({ id: ag.id, label: ag.label, percentage: '' })));
  }, [platform]);

  // Adjust gaps array length when numPosts changes
  useEffect(() => {
    setGaps(prev => {
      const next = [...prev];
      while (next.length < numPosts - 1) next.push(next[next.length - 1] ?? 2);
      while (next.length > numPosts - 1) next.pop();
      return next;
    });
  }, [numPosts]);

  const handleCalculate = async () => {
    let params;
    let savedData;

    if (mode === 'acquisition') {
      const validGroups = acquisitionGroups.filter(g =>
        g.location?.offset != null && g.ageGroupId && parseFloat(g.weight) > 0
      );
      if (validGroups.length === 0) {
        setError('please add at least one group with a location, age group, and weight');
        return;
      }

      // Auto-normalize weights if they don't sum to 100
      let groups = acquisitionGroups;
      const totalW = validGroups.reduce((s, g) => s + parseFloat(g.weight), 0);
      if (Math.round(totalW) !== 100) {
        groups = acquisitionGroups.map(g => {
          const w = parseFloat(g.weight) || 0;
          return { ...g, weight: w > 0 ? Math.round((w / totalW) * 100) : '' };
        });
        setAcquisitionGroups(groups);
      }

      params = {
        groups: groups.filter(g =>
          g.location?.offset != null && g.ageGroupId && parseFloat(g.weight) > 0
        ),
        platformId: platform,
        platformConfig,
        windowDuration: algorithmWindow,
        numPosts,
        gaps,
      };
      savedData = {
        mode,
        platform,
        algorithmWindow,
        numPosts,
        gaps,
        acquisitionGroups: groups,
      };
    } else {
      const hasValidLocation = locations.some(l => l.offset != null && l.percentage && parseFloat(l.percentage) > 0);
      if (!hasValidLocation) {
        setError('please add at least one audience location and its respective percentage');
        return;
      }

      params = {
        locations: locations.map(l => ({ ...l, percentage: parseFloat(l.percentage) || 0 })),
        ageGroups: ageGroups.map(a => ({ ...a, percentage: parseFloat(a.percentage) || 0 })),
        gender: { men: parseFloat(gender.men) || 0, women: parseFloat(gender.women) || 0 },
        platformId: platform,
        platformConfig,
        windowDuration: algorithmWindow,
        numPosts,
        gaps,
      };
      savedData = {
        mode,
        platform,
        algorithmWindow,
        numPosts,
        gaps,
        locations,
        ageGroups,
        gender,
      };
    }

    setCalculating(true);

    let freshData = null;
    try {
      freshData = await refresh();
    } catch (e) {
      // fall back to baseline
    }

    const freshConfig = freshData ? {
      ...p,
      activityPeaks: { ...p.activityPeaks, ...(freshData.activityPeaks || {}) },
      dayMultipliers: { ...p.dayMultipliers, ...(freshData.dayMultipliers || {}) },
    } : platformConfig;

    const result = calculatePlans({ ...params, platformConfig: freshConfig });
    setResults(result);

    saveInput(savedData);

    setCalculating(false);
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const loadSavedInput = (saved) => {
    try {
      const data = JSON.parse(saved.input_data);
      if (data.platform) setPlatform(data.platform);
      if (data.mode) setMode(data.mode);
      if (data.algorithmWindow) setAlgorithmWindow(data.algorithmWindow);
      if (data.numPosts) setNumPosts(data.numPosts);
      if (data.gaps) setGaps(data.gaps);
      else if (data.minSpacing != null) setGaps(Array.from({ length: (data.numPosts || 1) - 1 }, () => data.minSpacing));
      if (data.locations) setLocations(data.locations);
      if (data.ageGroups) setAgeGroups(data.ageGroups);
      if (data.gender) setGender(data.gender);
      if (data.acquisitionGroups) setAcquisitionGroups(data.acquisitionGroups);
      setShowHistory(false);
    } catch (e) {
      // ignore parse errors
    }
  };

  const p = platforms[platform];
  const platformConfig = platformData ? {
    ...p,
    activityPeaks: { ...p.activityPeaks, ...(platformData.activityPeaks || {}) },
    dayMultipliers: { ...p.dayMultipliers, ...(platformData.dayMultipliers || {}) },
  } : undefined;

  return (
    <div className="min-h-screen pp-text relative">
      <AmbientBackground colorKey={`${schemeId}-${themeMode}`} />
      <div className="max-w-2xl mx-auto px-5 py-10 sm:py-14 space-y-8">
        {/* Header */}
        <Reveal>
          <header className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-2xl sm:text-3xl font-semibold pp-text tracking-tight">Post Peak</h1>
              <p className="text-sm pp-text-muted">Post when the algorithm is watching.</p>
            </div>
            <ColorSchemeSettings
              schemeId={schemeId}
              setSchemeId={setSchemeId}
              themeMode={themeMode}
              toggleTheme={toggleTheme}
            />
          </header>
        </Reveal>

        {/* Platform */}
        <Reveal>
          <section className="space-y-3">
            <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Platform</h2>
            <TiltCard tilt={false} className="p-4">
              <PlatformSelector value={platform} onChange={setPlatform} />
            </TiltCard>
          </section>
        </Reveal>

        {/* Function */}
        <Reveal>
          <section className="space-y-3">
            <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Function</h2>
            <TiltCard tilt={false} className="p-4">
              <FunctionModeSelector value={mode} onChange={setMode} />
            </TiltCard>
          </section>
        </Reveal>

        {mode === 'acquisition' ? (
          <>
            <section className="space-y-3">
              <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Target Demographics</h2>
              <TiltCard tilt={false} className="p-4">
                <AcquisitionGroups
                  value={acquisitionGroups}
                  onChange={setAcquisitionGroups}
                  ageGroups={p.ageGroups}
                />
              </TiltCard>
            </section>

            <section className="space-y-3">
              <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Posting Strategy</h2>
              <TiltCard tilt={false} className="p-4">
                <div className="space-y-5">
                  <AlgorithmWindowControl value={algorithmWindow} onChange={setAlgorithmWindow} />
                  <MultiPostControls
                    numPosts={numPosts}
                    gaps={gaps}
                    onNumPostsChange={setNumPosts}
                    onGapsChange={setGaps}
                  />
                </div>
              </TiltCard>
            </section>
          </>
        ) : (
          <>
            <section className="space-y-3">
              <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Posting Strategy</h2>
              <TiltCard tilt={false} className="p-4">
                <div className="space-y-5">
                  <AlgorithmWindowControl value={algorithmWindow} onChange={setAlgorithmWindow} />
                  <MultiPostControls
                    numPosts={numPosts}
                    gaps={gaps}
                    onNumPostsChange={setNumPosts}
                    onGapsChange={setGaps}
                  />
                </div>
              </TiltCard>
            </section>

            <section className="space-y-3">
              <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">Audience Locations</h2>
              <TiltCard tilt={false} className="p-4">
                <LocationInputs value={locations} onChange={setLocations} />
              </TiltCard>
            </section>

            <section className="space-y-3">
              <h2 className="text-xs font-medium pp-text-muted uppercase tracking-wider">{p.name} Demographics</h2>
              <TiltCard tilt={false} className="p-4">
                <div className="space-y-4">
                  {p.hasAge && (
                    <AgeGroupInputs ageGroups={p.ageGroups} value={ageGroups} onChange={setAgeGroups} />
                  )}
                  {p.hasGender && (
                    <GenderInputs value={gender} onChange={setGender} />
                  )}
                </div>
              </TiltCard>
            </section>
          </>
        )}

        {/* Calculate */}
        <div className="pt-2">
          <button
            onClick={handleCalculate}
            disabled={calculating}
            className="group flex items-center justify-center gap-2 w-full py-4 rounded-2xl pp-primary-bg text-white font-medium text-[15px] pp-btn-glow disabled:opacity-50"
          >
            {calculating ? (refreshing ? 'Sourcing fresh data…' : 'Calculating…') : 'Calculate Optimal Posting Times'}
            {!calculating && (
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
            )}
          </button>
        </div>

        {/* Error */}
        <ErrorMessage message={error} onDismiss={() => setError('')} />

        {/* Results */}
        {results && (
          <Reveal>
            <div ref={resultsRef} className="space-y-5">
              <ResultsPanel results={results} />
            </div>
          </Reveal>
        )}

        {/* History */}
        {savedInputs.length > 0 && (
          <section className="pt-2 space-y-2">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 w-full text-left"
            >
              <History className="w-3.5 h-3.5 pp-text-muted" />
              <span className="text-xs font-medium pp-text-muted uppercase tracking-wider">Recent</span>
              <span className="text-xs pp-text-muted">({savedInputs.length})</span>
              {showHistory
                ? <ChevronUp className="w-4 h-4 ml-auto pp-text-muted" />
                : <ChevronDown className="w-4 h-4 ml-auto pp-text-muted" />}
            </button>
            {showHistory && (
              <div className="space-y-1.5">
                {savedInputs.map((s, i) => {
                  let data = {};
                  try { data = JSON.parse(s.input_data); } catch (e) {}
                  return (
                    <button
                      key={s.id || i}
                      onClick={() => loadSavedInput(s)}
                      className="flex items-center gap-3 w-full p-3 rounded-xl border pp-border pp-card pp-hover text-left transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium pp-text">
                          {platforms[data.platform]?.name || 'Unknown'}
                          <span className="pp-text-muted font-normal">
                            {data.mode === 'acquisition' ? ' · Acquisition' : ' · Maximize'}
                          </span>
                          {data.numPosts > 1 && ` · ${data.numPosts} posts`}
                        </div>
                        <div className="text-xs pp-text-muted truncate">
                          {data.mode === 'acquisition'
                            ? `${(data.acquisitionGroups || []).filter(g => g.location?.country).length} groups`
                            : (data.locations || []).filter(l => l.country).map(l => l.country).join(', ') || 'No locations'}
                        </div>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 pp-text-muted shrink-0" />
                    </button>
                  );
                })}
              </div>
            )}
          </section>
        )}
      </div>
    </div>
  );
}