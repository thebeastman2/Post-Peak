// Platform configurations with demographic data and activity models.
// Activity peaks use Gaussian functions: weight * exp(-((h - peak)² / (2σ²)))

export const platforms = {
  instagram: {
    id: 'instagram',
    name: 'Instagram',
    emoji: '📷',
    label: 'Instagram Reels',
    ageGroups: [
      { id: '13-17', label: '13–17 years' },
      { id: '18-24', label: '18–24 years' },
      { id: '25-34', label: '25–34 years' },
      { id: '35-44', label: '35–44 years' },
      { id: '45-54', label: '45–54 years' },
      { id: '55-64', label: '55–64 years' },
      { id: '65+', label: '65+ years' },
    ],
    hasGender: true,
    hasAge: true,
    activityPeaks: {
      '13-17': [{ h: 15, w: 1.0, s: 2.5 }, { h: 21, w: 1.5, s: 2.5 }],
      '18-24': [{ h: 12, w: 0.8, s: 2.5 }, { h: 19, w: 1.3, s: 3 }, { h: 22, w: 1.5, s: 2.5 }],
      '25-34': [{ h: 12.5, w: 0.9, s: 2.5 }, { h: 20.5, w: 1.5, s: 3 }],
      '35-44': [{ h: 8.5, w: 1.0, s: 2.5 }, { h: 19, w: 1.2, s: 3 }],
      '45-54': [{ h: 8.5, w: 1.0, s: 2.5 }, { h: 19, w: 1.1, s: 3 }],
      '55-64': [{ h: 9, w: 1.2, s: 2.5 }, { h: 17.5, w: 0.9, s: 3 }],
      '65+': [{ h: 9, w: 1.2, s: 2.5 }, { h: 17.5, w: 0.9, s: 3 }],
    },
    dayMultipliers: {
      monday: 0.95, tuesday: 0.93, wednesday: 0.95, thursday: 1.0,
      friday: 1.08, saturday: 1.12, sunday: 1.05,
    },
  },
  tiktok: {
    id: 'tiktok',
    name: 'TikTok',
    emoji: '🎵',
    label: 'TikTok Videos',
    ageGroups: [
      { id: '13-17', label: '13–17 years' },
      { id: '18-24', label: '18–24 years' },
      { id: '25-34', label: '25–34 years' },
      { id: '35-44', label: '35–44 years' },
      { id: '45-54', label: '45–54 years' },
      { id: '55+', label: '55+ years' },
    ],
    hasGender: true,
    hasAge: true,
    activityPeaks: {
      '13-17': [{ h: 7, w: 0.8, s: 2 }, { h: 15, w: 1.0, s: 2.5 }, { h: 21, w: 1.5, s: 2.5 }],
      '18-24': [{ h: 6, w: 0.7, s: 2 }, { h: 10, w: 0.8, s: 3 }, { h: 16, w: 1.0, s: 3 }, { h: 22, w: 1.5, s: 2.5 }],
      '25-34': [{ h: 9, w: 0.8, s: 2.5 }, { h: 12, w: 0.9, s: 2.5 }, { h: 19, w: 1.4, s: 3 }],
      '35-44': [{ h: 8, w: 0.9, s: 2.5 }, { h: 12, w: 0.8, s: 2.5 }, { h: 20, w: 1.3, s: 3 }],
      '45-54': [{ h: 8, w: 0.9, s: 2.5 }, { h: 19, w: 1.2, s: 3 }],
      '55+': [{ h: 9, w: 1.0, s: 2.5 }, { h: 17, w: 0.9, s: 3 }],
    },
    dayMultipliers: {
      monday: 0.92, tuesday: 0.90, wednesday: 0.95, thursday: 1.0,
      friday: 1.10, saturday: 1.15, sunday: 1.08,
    },
  },
  snapchat: {
    id: 'snapchat',
    name: 'Snapchat Spotlight',
    emoji: '👻',
    label: 'Snapchat Spotlight',
    ageGroups: [
      { id: '13-17', label: '13–17 years' },
      { id: '18-24', label: '18–24 years' },
      { id: '25-34', label: '25–34 years' },
      { id: '35-44', label: '35–44 years' },
      { id: '45+', label: '45+ years' },
    ],
    hasGender: true,
    hasAge: true,
    activityPeaks: {
      '13-17': [{ h: 8, w: 0.8, s: 2 }, { h: 15, w: 1.2, s: 2.5 }, { h: 21, w: 1.5, s: 2.5 }],
      '18-24': [{ h: 12, w: 1.0, s: 2.5 }, { h: 19, w: 1.5, s: 3 }, { h: 23, w: 1.2, s: 2 }],
      '25-34': [{ h: 12, w: 1.0, s: 2.5 }, { h: 19, w: 1.4, s: 3 }],
      '35-44': [{ h: 9, w: 0.9, s: 2.5 }, { h: 18, w: 1.2, s: 3 }],
      '45+': [{ h: 9, w: 1.0, s: 2.5 }, { h: 17, w: 0.9, s: 3 }],
    },
    dayMultipliers: {
      monday: 0.90, tuesday: 0.88, wednesday: 0.92, thursday: 0.98,
      friday: 1.12, saturday: 1.18, sunday: 1.05,
    },
  },
  youtube: {
    id: 'youtube',
    name: 'YouTube Shorts',
    emoji: '▶️',
    label: 'YouTube Shorts',
    ageGroups: [
      { id: '13-17', label: '13–17 years' },
      { id: '18-24', label: '18–24 years' },
      { id: '25-34', label: '25–34 years' },
      { id: '35-44', label: '35–44 years' },
      { id: '45-54', label: '45–54 years' },
      { id: '55-64', label: '55–64 years' },
      { id: '65+', label: '65+ years' },
    ],
    hasGender: true,
    hasAge: true,
    activityPeaks: {
      '13-17': [{ h: 15, w: 1.2, s: 2.5 }, { h: 20, w: 1.5, s: 2.5 }],
      '18-24': [{ h: 14, w: 1.0, s: 3 }, { h: 21, w: 1.5, s: 2.5 }],
      '25-34': [{ h: 12, w: 0.9, s: 2.5 }, { h: 20, w: 1.4, s: 3 }],
      '35-44': [{ h: 9, w: 1.0, s: 2.5 }, { h: 19, w: 1.3, s: 3 }],
      '45-54': [{ h: 9, w: 1.0, s: 2.5 }, { h: 19, w: 1.2, s: 3 }],
      '55-64': [{ h: 9, w: 1.0, s: 2.5 }, { h: 18, w: 1.1, s: 3 }],
      '65+': [{ h: 10, w: 1.0, s: 2.5 }, { h: 17, w: 0.9, s: 3 }],
    },
    dayMultipliers: {
      monday: 0.94, tuesday: 0.92, wednesday: 0.95, thursday: 1.0,
      friday: 1.08, saturday: 1.15, sunday: 1.10,
    },
  },
  facebook: {
    id: 'facebook',
    name: 'Facebook Reels',
    emoji: '📘',
    label: 'Facebook Reels',
    ageGroups: [
      { id: '13-17', label: '13–17 years' },
      { id: '18-24', label: '18–24 years' },
      { id: '25-34', label: '25–34 years' },
      { id: '35-44', label: '35–44 years' },
      { id: '45-54', label: '45–54 years' },
      { id: '55-64', label: '55–64 years' },
      { id: '65+', label: '65+ years' },
    ],
    hasGender: true,
    hasAge: true,
    activityPeaks: {
      '13-17': [{ h: 15, w: 0.9, s: 2.5 }, { h: 21, w: 1.4, s: 2.5 }],
      '18-24': [{ h: 9, w: 0.7, s: 2.5 }, { h: 13, w: 0.8, s: 2.5 }, { h: 20, w: 1.4, s: 3 }],
      '25-34': [{ h: 9, w: 0.8, s: 2.5 }, { h: 13, w: 0.9, s: 2.5 }, { h: 20, w: 1.3, s: 3 }],
      '35-44': [{ h: 9, w: 0.9, s: 2.5 }, { h: 13, w: 0.8, s: 2.5 }, { h: 19, w: 1.2, s: 3 }],
      '45-54': [{ h: 9, w: 0.9, s: 2.5 }, { h: 12, w: 0.8, s: 2.5 }, { h: 19, w: 1.1, s: 3 }],
      '55-64': [{ h: 10, w: 1.0, s: 2.5 }, { h: 15, w: 0.8, s: 3 }, { h: 19, w: 1.0, s: 3 }],
      '65+': [{ h: 10, w: 1.0, s: 2.5 }, { h: 15, w: 0.8, s: 3 }, { h: 18, w: 0.9, s: 3 }],
    },
    dayMultipliers: {
      monday: 0.93, tuesday: 0.95, wednesday: 1.0, thursday: 1.02,
      friday: 1.05, saturday: 1.08, sunday: 1.03,
    },
  },
};

export const platformList = Object.values(platforms);

export const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
export const dayLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const dayLabelsShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];